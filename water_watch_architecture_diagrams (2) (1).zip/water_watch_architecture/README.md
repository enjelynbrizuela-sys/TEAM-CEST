# Water Watch — Architecture Diagram Sources

Project basis: Team Brainstorming Worksheet (Unit 2). Selected idea: **Water Refilling Price Comparison & Group Ordering App**.

## MVP scope used for these provisional diagrams
- Browse water-refilling stations and compare listed prices.
- View station details and delivery information.
- Create/join a group order.
- Submit an order request and view its status.
- Station/operator can maintain station details, prices, and order status.
- Optional featured listings are treated as a later/monetization capability, not required for the core MVP.

## Important assumptions to validate
1. Prices and station listings are entered/updated by station operators or an administrator; no live price feed is assumed.
2. The MVP records orders and delivery preferences but does not process online payments.
3. Group ordering coordinates requests; actual delivery and payment arrangements are confirmed with the station.
4. Authentication is assumed for customers and station operators.
5. Deployment technology and hosting provider are not yet selected, so deployment nodes are generic and provisional.

## Diagram files
1. `context.md` — C4 system context
2. `containers.md` — C4 container view
3. `use-cases.md` — use case diagram
4. `activity.md` — activity/workflow diagram
5. `sequence.md` — sequence diagram
6. `class.md` — class diagram
7. `state-machine.md` — order state machine
8. `packages.md` — package diagram
9. `components.md` — component diagram
10. `deployment.md` — provisional deployment diagram
11. `erd.md` — entity relationship diagram

Open any `.md` file in a Mermaid-compatible editor, such as Mermaid Live Editor, to render it. Review every assumption with the team before submitting. Keep the diagrams consistent as the MVP requirements become clearer.
